﻿using System;
using KAI.FSA; 

namespace Miner49er
{
   
    public class SimpleMiner : FSAImpl, Miner
    {
       
        public int gold = 0;
        
        public int thirst = 0;
       
        public int bank = 0;

       
        State miningState;
        State drinkingState;
        State bankingState;

       
        public SimpleMiner() : base("SimpleMiner")
        {
            
            miningState = MakeNewState("Mining");
            drinkingState = MakeNewState("Drinking");
            bankingState = MakeNewState("Banking");

           
            miningState.addTransition("tick",
                new ConditionDelegate[] { new ConditionDelegate(this.parched) },
                new ActionDelegate[] { new ActionDelegate(this.incrementThirst) }, drinkingState);
            
            miningState.addTransition("tick",
                new ConditionDelegate[] { new ConditionDelegate(this.pocketsFull) },
                new ActionDelegate[] { new ActionDelegate(this.incrementThirst) }, bankingState);
            
            miningState.addTransition("tick",
                new ConditionDelegate[] { }, 
                new ActionDelegate[] { new ActionDelegate(this.dig) }, miningState);

            
            drinkingState.addTransition("tick",
                new ConditionDelegate[] { new ConditionDelegate(this.thirsty) },
                new ActionDelegate[] { new ActionDelegate(this.takeDrink) }, drinkingState);
            
            drinkingState.addTransition("tick",
                new ConditionDelegate[] { },
                new ActionDelegate[] { new ActionDelegate(this.incrementThirst) }, miningState);

            
            bankingState.addTransition("tick",
                new ConditionDelegate[] { new ConditionDelegate(this.pocketsNotEmpty) },
                new ActionDelegate[] { new ActionDelegate(this.depositGold) }, bankingState);

            bankingState.addTransition("tick",
                new ConditionDelegate[] { new ConditionDelegate(this.parched) },
                new ActionDelegate[] { }, drinkingState);
            
            bankingState.addTransition("tick",
                new ConditionDelegate[] { },
                new ActionDelegate[] { }, miningState);

           
            SetCurrentState(miningState);
        }

       
        private Boolean parched(FSA fsa)
        {
            if (thirst >= 6)
            {
                Console.WriteLine("Too thirsty too work.");
            }
            return thirst >= 6;
        }

       
        private void takeDrink(FSA fsa)
        {
            thirst -= 2;
            Console.WriteLine("Glug glug glug");
        }

       
        private void depositGold(FSA fsa)
        {
            gold -= 1;
            bank += 1;
            Console.WriteLine("deposit a gold nugget");
        }

       
        public int getCurrentWealth()
        {
            return bank + gold;
        }

        

        private void dig(FSA fsa)
        {
            gold++;
            thirst++;
            Console.WriteLine("Miner is digging.");
        }

        private void incrementThirst(FSA fsa)
        {
            thirst++;
        }

        private Boolean pocketsFull(FSA fsa) => gold >= 7;

        private Boolean pocketsNotEmpty(FSA fsa) => gold > 0;

        private Boolean thirsty(FSA fsa) => thirst > 0;

        public void printStatus()
        {
            Console.WriteLine("Thirst: "+thirst+" Gold: "+gold+" Bank: "+bank);
        }
    }
}